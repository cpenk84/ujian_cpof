configure({
  configs: [
    './test.js'
  ]
})
