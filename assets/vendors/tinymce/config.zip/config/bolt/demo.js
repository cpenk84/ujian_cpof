configure({
  configs: [
    './prod.js'
  ]
})
