configure({
  configs: [
    './test.js'
  ]
});
