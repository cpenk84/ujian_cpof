configure({
  configs: [
    './test.js'
  ]
});