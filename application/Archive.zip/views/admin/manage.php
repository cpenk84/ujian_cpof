<h1>Manage</h1>

<?php echo anchor('/dashboard', "Dashboard"); ?>

<ul>
    <li><?php echo anchor('/admin/permissions', "Manage Permission's"); ?></li>
    <li><?php echo anchor('/admin/groups', "Manage Group's"); ?></li>
    <li><?php echo anchor('/admin/users', "Manage User's"); ?></li>
    <li><?php echo anchor('/auth', "Manage Auth"); ?></li>
</ul>
